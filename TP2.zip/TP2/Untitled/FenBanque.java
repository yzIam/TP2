public class FenBanque{
    //attributs
    private carte;
    
    //methodes
}