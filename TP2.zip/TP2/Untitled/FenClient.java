public class FenClient extends Carte{

//methodes
public Carte FenCLient(Carte noCarte){
    super(noCarte)
}
public void afficherSoldes() {}


}
