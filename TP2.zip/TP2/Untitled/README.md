# TP2

https://crosemont-my.sharepoint.com/:b:/g/personal/asahraoui_crosemont_qc_ca/EX6FAwPp4ChDhorqjczYW9UBqULiJcBtaZjUcuYmmtsyqA?e=uFd3Rn

