/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author itsyz
 */
public class FenClient extends Carte{

//methodes
public Carte FenCLient(Carte noCarte){
    super(noCarte)
}
public void afficherSoldes() {}

public void afficherTransactions() {}

public void btnPremierActionPerformed(etv) {}

public void btnSuivantActionPerformed(etv) {}

public void btnPrecedentActionPerformed(etv) {}
}
